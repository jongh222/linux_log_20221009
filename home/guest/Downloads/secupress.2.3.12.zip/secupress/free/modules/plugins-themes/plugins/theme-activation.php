<?php
/**
 * Module Name: No Theme Switch
 * Description: Disable the theme switch action
 * Main Module: plugins_themes
 * Author: SecuPress
 * Version: 1.1
 */

// Deprecated in 2.2.6, see "theme-installation.php"