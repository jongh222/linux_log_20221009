<?php
/**
 * Module Name: No Plugin Deletion
 * Description: Disable the plugin deletion action
 * Main Module: plugins_themes
 * Author: SecuPress
 * Version: 1.1
 */

// Deprecated in 2.2.6, see "plugin-installation.php"