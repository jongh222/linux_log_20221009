<?php
/**
 * Module Name: No Plugin Activation/Deactivation
 * Description: Disable the plugin activation & deactivation actions
 * Main Module: plugins_themes
 * Author: SecuPress
 * Version: 1.1
 */

// Deprecated in 2.2.6, see "plugin-installation.php"
