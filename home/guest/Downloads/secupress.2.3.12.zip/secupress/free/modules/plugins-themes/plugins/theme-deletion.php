<?php
/**
 * Module Name: No Theme Deletion
 * Description: Disable the theme deletion action
 * Main Module: plugins_themes
 * Author: SecuPress
 * Version: 1.1
 */

// Deprecated in 2.2.6, see "theme-installation.php"