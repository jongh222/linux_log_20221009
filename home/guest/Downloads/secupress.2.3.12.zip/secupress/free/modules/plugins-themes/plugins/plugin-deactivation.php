<?php
/**
 * Module Name: No Plugin Deactivation
 * Description: Disable the plugin deactivation action
 * Main Module: plugins_themes
 * Author: SecuPress
 * Version: 1.1
 */

// Deprecated in 2.2.6, see "plugin-installation.php"