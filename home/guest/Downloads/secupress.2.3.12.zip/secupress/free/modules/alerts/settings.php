<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

$this->load_plugin_settings( 'notification-types' );
$this->load_plugin_settings( 'event-alerts' );
$this->load_plugin_settings( 'daily-reporting' );
