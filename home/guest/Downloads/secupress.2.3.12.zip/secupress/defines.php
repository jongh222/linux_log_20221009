<?php
defined( 'ABSPATH' ) or die( 'Something went wrong.' );

define( 'SECUPRESS_VERSION'                   , '2.3.12' );
define( 'SECUPRESS_MAJOR_VERSION'             , '2.3' );
define( 'SECUPRESS_UPDATE_API_KEY'            , 'aHR0cHM6Ly9zZWN1cHJlc3MubWUv' );
define( 'SECUPRESS_PATH'                      , realpath( dirname( SECUPRESS_FILE ) ) . DIRECTORY_SEPARATOR );
define( 'SECUPRESS_INC_PATH'                  , SECUPRESS_PATH . 'free' . DIRECTORY_SEPARATOR );
